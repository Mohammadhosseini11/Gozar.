package com.gozar.vpn

import android.content.Context
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import org.json.JSONObject
import java.io.File

/**
 * JNI wrapper for the same hev-socks5-tunnel bridge used by v2rayNG.
 * The bridge consumes Android's TUN fd and forwards TCP/UDP via the local Xray SOCKS5 inbound.
 */
internal object TProxyService {
    private const val TAG = "GozarTun2Socks"
    @Volatile private var running = false

    @JvmStatic
    private external fun TProxyStartService(configPath: String, fd: Int): Boolean
    @JvmStatic
    private external fun TProxyStopService(): Boolean
    @JvmStatic
    private external fun TProxyIsRunning(): Boolean

    init {
        System.loadLibrary("hev-socks5-tunnel")
    }

    @Synchronized
    fun start(context: Context, tun: ParcelFileDescriptor, params: JSONObject): Boolean {
        if (running && isRunningSafely()) return true
        val port = params.optInt("socksPort", 10808).coerceIn(1024, 65535)
        val mtu = params.optInt("mtu", 1500).coerceIn(576, 9000)
        val ipv4 = params.optString("tunIpv4", "10.111.111.1").ifBlank { "10.111.111.1" }
        val logLevel = params.optString("hevLogLevel", "warn").let {
            if (it in setOf("debug", "info", "warn", "error", "none")) it else "warn"
        }
        val timeouts = params.optString("hevTimeouts", "300,60").split(',')
        val tcpMs = (timeouts.getOrNull(0)?.trim()?.toIntOrNull() ?: 300).coerceIn(10, 3600) * 1000
        val udpMs = (timeouts.getOrNull(1)?.trim()?.toIntOrNull() ?: 60).coerceIn(10, 3600) * 1000
        val config = """tunnel:
  mtu: $mtu
  ipv4: '$ipv4'
socks5:
  port: $port
  address: '127.0.0.1'
  udp: 'udp'
misc:
  tcp-read-write-timeout: $tcpMs
  udp-read-write-timeout: $udpMs
  log-level: $logLevel
"""
        val configFile = File(context.filesDir, "hev-socks5-tunnel.yaml")
        configFile.writeText(config)
        return try {
            val ok = TProxyStartService(configFile.absolutePath, tun.fd)
            running = ok || isRunningSafely()
            Log.i(TAG, "hev start result=$ok, nativeRunning=$running, config=$configFile")
            running
        } catch (t: Throwable) {
            running = false
            Log.e(TAG, "Unable to start hev-socks5-tunnel", t)
            throw t
        }
    }

    @Synchronized
    fun stop() {
        try {
            if (running || isRunningSafely()) TProxyStopService()
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to stop hev-socks5-tunnel", t)
        } finally {
            running = false
        }
    }

    private fun isRunningSafely(): Boolean = try { TProxyIsRunning() } catch (_: Throwable) { false }
}
