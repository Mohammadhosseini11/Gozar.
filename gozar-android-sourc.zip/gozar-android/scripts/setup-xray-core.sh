#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_LIBS="$ROOT/app/libs"
mkdir -p "$APP_LIBS"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
if [[ -z "${NDK_HOME:-}" ]]; then
  [[ -d "$ANDROID_HOME/ndk" ]] || { echo "Install Android NDK first." >&2; exit 1; }
  NDK_HOME="$(find "$ANDROID_HOME/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
  export NDK_HOME
fi
export ANDROID_HOME NDK_HOME

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# Xray configs may contain geosite:* and geoip:* routing rules. The core expects
# these files in the writable app-private directory initialized by GozarVpnService.
ASSETS_DIR="$ROOT/app/src/main/assets"
mkdir -p "$ASSETS_DIR"
echo "[1/4] Downloading Xray geodata…"
curl --fail --location --retry 3 \
  https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat \
  --output "$ASSETS_DIR/geosite.dat"
curl --fail --location --retry 3 \
  https://github.com/Loyalsoldier/geoip/releases/latest/download/geoip.dat \
  --output "$ASSETS_DIR/geoip.dat"
test -s "$ASSETS_DIR/geosite.dat"
test -s "$ASSETS_DIR/geoip.dat"
ls -lh "$ASSETS_DIR/geosite.dat" "$ASSETS_DIR/geoip.dat"

echo "[2/4] Fetching upstream v2rayNG build inputs and pinned submodules…"
git clone --recurse-submodules https://github.com/2dust/v2rayNG.git "$TMP/v2rayNG"
CORE_DIR="$TMP/v2rayNG/AndroidLibXrayLite"
git -C "$CORE_DIR" fetch --tags --force
CORE_TAG="$(git -C "$CORE_DIR" describe --tags --abbrev=0)"
echo "Using AndroidLibXrayLite tag: $CORE_TAG"
echo "[3/4] Downloading the matching official libv2ray.aar…"
curl --fail --location --retry 3 \
  "https://github.com/2dust/AndroidLibXrayLite/releases/download/${CORE_TAG}/libv2ray.aar" \
  --output "$APP_LIBS/libv2ray.aar"
echo "[4/4] Compiling native TUN bridge for Gozar (requires Android NDK/clang/make)…"
# The JNI bridge binds to com.gozar.vpn.GozarTun2Socks, not v2rayNG's package.
sed -i 's/-DPKGNAME=com\/v2ray\/ang\/service/-DPKGNAME=com\/gozar\/vpn/g' "$TMP/v2rayNG/compile-hevtun.sh"
(cd "$TMP/v2rayNG" && bash ./compile-hevtun.sh)
cp -a "$TMP/v2rayNG/libs/." "$APP_LIBS/"
echo "Prepared core:"; ls -lh "$APP_LIBS/libv2ray.aar"; find "$APP_LIBS" -name '*.so' -type f -print
echo "Now build Gozar from Android Studio."
