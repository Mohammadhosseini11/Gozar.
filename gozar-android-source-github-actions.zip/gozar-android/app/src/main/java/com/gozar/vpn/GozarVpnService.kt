package com.gozar.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import libv2ray.Libv2ray
import libv2ray.V2RayCallbacks
import libv2ray.V2RayVPNServiceSupportsSet
import org.json.JSONObject

/** Xray runtime bridge based on the public libv2ray API used by v2rayNG. */
class GozarVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.gozar.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.gozar.vpn.DISCONNECT"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_PARAMS = "vpn_params"
        private const val CHANNEL_ID = "gozar_vpn"
        private const val NOTIFICATION_ID = 7001
        private const val PREFS = "gozar_vpn_state"
        private const val KEY_STATE = "state"
        private const val KEY_LOG = "log"

        fun start(context: Context, config: String, params: String) {
            val intent = Intent(context, GozarVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_CONFIG, config)
                putExtra(EXTRA_PARAMS, params)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
        fun stop(context: Context) {
            context.startService(Intent(context, GozarVpnService::class.java).apply { action = ACTION_DISCONNECT })
        }
        fun state(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_STATE, "off") ?: "off"
        fun lastLog(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LOG, "هسته آماده است.") ?: "هسته آماده است."
    }

    private var tunInterface: ParcelFileDescriptor? = null
    private val point = Libv2ray.newV2RayPoint()
    private var configText = ""
    private var vpnParams = JSONObject()

    private val callbacks = object : V2RayCallbacks, V2RayVPNServiceSupportsSet {
        override fun shutdown(): Long { markState("off", "اتصال بسته شد."); return 0L }
        override fun getVPNFd(): Long = (tunInterface?.fd ?: -1).toLong()
        override fun prepare(): Long = 1L
        override fun protect(fd: Long): Long = if (this@GozarVpnService.protect(fd.toInt())) 0L else 1L
        override fun onEmitStatus(code: Long, message: String?): Long {
            val msg = message ?: "وضعیت هسته تغییر کرد."
            Log.i("GozarXray", msg)
            when {
                msg.contains("running", true) || msg.contains("started", true) -> markState("on", msg)
                msg.contains("closed", true) || msg.contains("stopped", true) -> markState("off", msg)
                else -> saveLog(msg)
            }
            return 0L
        }
        override fun setup(parameters: String?): Long = try {
            establishTun(parameters.orEmpty()); 0L
        } catch (e: Exception) {
            Log.e("GozarXray", "TUN setup failed", e)
            markState("error", "ساخت تونل VPN ناموفق بود: ${e.message}")
            -1L
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        point.packageName = packageName
        point.callbacks = callbacks
        point.setVpnSupportSet(callbacks)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> { stopCore(); return START_NOT_STICKY }
            ACTION_CONNECT -> {
                configText = intent.getStringExtra(EXTRA_CONFIG).orEmpty()
                vpnParams = try { JSONObject(intent.getStringExtra(EXTRA_PARAMS) ?: "{}") } catch (_: Exception) { JSONObject() }
                if (configText.isBlank()) {
                    markState("error", "پیکربندی اتصال خالی است."); stopSelf(); return START_NOT_STICKY
                }
                startForeground(NOTIFICATION_ID, makeNotification("در حال اتصال…"))
                markState("connecting", "در حال راه‌اندازی هسته Xray…")
                Thread({ startCore() }, "Gozar-Xray-start").start()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCore() {
        try {
            point.configureFile = "V2Ray_internal/ConfigureFileContent"
            point.configureFileContent = configText
            point.runLoop()
            if (point.isRunning) markState("on", "هسته Xray فعال است.")
        } catch (e: Throwable) {
            Log.e("GozarXray", "Core start failed", e)
            markState("error", "راه‌اندازی هسته ناموفق بود: ${e.message ?: e.javaClass.simpleName}")
            stopCore()
        }
    }

    private fun establishTun(parameters: String) {
        val builder = Builder().setSession("Gozar VPN")
        builder.setMtu(vpnParams.optInt("mtu", 1500).coerceIn(576, 9000))
        parameters.trim().split(Regex("\\s+")).forEach { token ->
            val bits = token.split(",")
            if (bits.isEmpty()) return@forEach
            when (bits[0].firstOrNull()) {
                'a' -> if (bits.size >= 3) builder.addAddress(bits[1], bits[2].toInt())
                'r' -> if (bits.size >= 3) builder.addRoute(bits[1], bits[2].toInt())
                's' -> if (bits.size >= 2) builder.addSearchDomain(bits[1])
                'm' -> if (bits.size >= 2) bits[1].toIntOrNull()?.let { builder.setMtu(it.coerceIn(576, 9000)) }
            }
        }
        vpnParams.optString("dns", "1.1.1.1").split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach {
            builder.addDnsServer(it)
        }
        // Xray's own outbound sockets are excluded with VpnService.protect() in the callback.
        // Do not exclude the whole Gozar package, or app traffic would bypass the VPN.
        tunInterface?.close()
        tunInterface = builder.establish() ?: error("Android did not establish the VPN interface")
        saveLog("رابط TUN ساخته شد.")
    }

    private fun stopCore() {
        try { if (point.isRunning) point.stopLoop() } catch (e: Exception) { Log.w("GozarXray", "Stop failed", e) }
        try { tunInterface?.close() } catch (_: Exception) { }
        tunInterface = null
        markState("off", "اتصال قطع شد.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun makeNotification(text: String): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = Notification.Builder(this, CHANNEL_ID)
        return builder.setContentTitle("Gozar").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(pending).setOngoing(true).build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Gozar VPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun markState(state: String, message: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATE, state).putString(KEY_LOG, message).apply()
        if (state == "on") getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, makeNotification("اتصال برقرار است"))
    }
    private fun saveLog(message: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LOG, message).apply()
    }
    override fun onRevoke() { stopCore(); super.onRevoke() }
    override fun onDestroy() {
        try { if (point.isRunning) point.stopLoop() } catch (_: Exception) { }
        try { tunInterface?.close() } catch (_: Exception) { }
        tunInterface = null
        super.onDestroy()
    }
}
