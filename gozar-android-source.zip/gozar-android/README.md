# Gozar Android — supplied HTML UI + Xray core integration

The Android host loads the supplied `index.html` and routes its `startVpn(config)` bridge to the Xray Android binding used by `2dust/v2rayNG`.

## Prepare core binaries

Requirements: Android Studio/SDK, JDK 17, Git, curl, Android NDK, and internet access.

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
export NDK_HOME="$ANDROID_HOME/ndk/<installed-version>"
./scripts/setup-xray-core.sh
```

The script fetches `libv2ray.aar` from the official `2dust/AndroidLibXrayLite` release and builds the native `hev-socks5-tunnel` bridge from the submodule pinned by upstream v2rayNG. Then open the project in Android Studio and select **Build → Build APK(s)**.

## Xray geodata

The `scripts/setup-xray-core.sh` build-preparation script downloads the official `geosite.dat` and `geoip.dat` release files before building the APK. On startup, the Android service copies them from packaged assets into the app-private writable `assets` directory passed to `Libv2ray.initCoreEnv`. This is required for configurations using rules such as `geosite:category-ads-all` or `geoip:private`.

## Scope and limitations

- The service uses the current `CoreController` / `CoreCallbackHandler` API exposed by `AndroidLibXrayLite`, creates an Android TUN interface, and passes its file descriptor to the Xray core. It is wired to the Xray JSON produced by the Gozar HTML interface and requests Android VPN permission before connecting.
- Hysteria2 and TUIC entries in the UI are not supported by the Xray engine; they require a separate sing-box/libbox integration.
- This environment has no network access, Gradle installation, Android SDK or NDK, so core binaries could not be downloaded and this project could not be compiled or device-tested here. The integration source must be verified against the exact upstream AAR version during the first Android Studio build.
- `2dust/AndroidLibXrayLite` identifies its license as LGPL-3.0; `2dust/v2rayNG` identifies its license as GPL-3.0. Review and follow applicable license and source-distribution obligations before redistribution.

## Upstream sources

- https://github.com/2dust/v2rayNG
- https://github.com/2dust/AndroidLibXrayLite
