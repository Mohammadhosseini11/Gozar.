#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_LIBS="$ROOT/app/libs"
mkdir -p "$APP_LIBS"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
if [[ -z "${NDK_HOME:-}" ]]; then
  [[ -d "$ANDROID_HOME/ndk" ]] || { echo "Install Android NDK first." >&2; exit 1; }
  NDK_HOME="$(find "$ANDROID_HOME/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
  export NDK_HOME
fi
export ANDROID_HOME NDK_HOME

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "[1/3] Fetching upstream v2rayNG build inputs and pinned submodules…"
git clone --recurse-submodules https://github.com/2dust/v2rayNG.git "$TMP/v2rayNG"
CORE_DIR="$TMP/v2rayNG/AndroidLibXrayLite"
git -C "$CORE_DIR" fetch --tags --force
CORE_TAG="$(git -C "$CORE_DIR" describe --tags --abbrev=0)"
echo "Using AndroidLibXrayLite tag: $CORE_TAG"
echo "[2/3] Downloading the matching official libv2ray.aar…"
curl --fail --location --retry 3 \
  "https://github.com/2dust/AndroidLibXrayLite/releases/download/${CORE_TAG}/libv2ray.aar" \
  --output "$APP_LIBS/libv2ray.aar"
echo "[3/3] Compiling native TUN bridge (requires Android NDK/clang/make)…"
(cd "$TMP/v2rayNG" && bash ./compile-hevtun.sh)
cp -a "$TMP/v2rayNG/libs/." "$APP_LIBS/"
echo "Prepared core:"; ls -lh "$APP_LIBS/libv2ray.aar"; find "$APP_LIBS" -name '*.so' -type f -print
echo "Now build Gozar from Android Studio."
