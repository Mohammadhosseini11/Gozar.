package com.gozar.vpn

import android.annotation.SuppressLint
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import java.net.InetSocketAddress
import java.net.Socket

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    @Volatile private var pendingConfig = ""
    @Volatile private var pendingParams = "{}"
    private val vpnPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            GozarVpnService.start(this, pendingConfig, pendingParams)
            toast("درخواست اتصال ارسال شد.")
        } else toast("مجوز VPN داده نشد.")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(10, 15, 13)
        window.navigationBarColor = android.graphics.Color.rgb(10, 15, 13)
        window.decorView.systemUiVisibility = 0
        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(10, 15, 13))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(GozarBridge(), "GozarAndroid")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (webView.canGoBack()) webView.goBack() else finish() }
        })
    }
    private fun toast(message: String) = runOnUiThread {
        Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
    }
    inner class GozarBridge {
        @JavascriptInterface fun vpnStatus(): String = GozarVpnService.state(this@MainActivity)
        @JavascriptInterface fun startVpn(config: String): String {
            if (config.isBlank()) return "invalid"
            pendingConfig = config
            pendingParams = getSharedPreferences("gozar_vpn_params", MODE_PRIVATE).getString("params", "{}") ?: "{}"
            val prepare = VpnService.prepare(this@MainActivity)
            if (prepare != null) {
                runOnUiThread { vpnPermissionLauncher.launch(prepare) }
                return "ask"
            }
            GozarVpnService.start(this@MainActivity, config, pendingParams)
            return "starting"
        }
        @JavascriptInterface fun stopVpn() { runOnUiThread { GozarVpnService.stop(this@MainActivity) } }
        @JavascriptInterface fun setVpnParams(params: String) {
            getSharedPreferences("gozar_vpn_params", MODE_PRIVATE).edit().putString("params", params).apply()
            pendingParams = params
        }
        @JavascriptInterface fun tcpPing(server: String, port: Int): String = try {
            val start = System.currentTimeMillis()
            Socket().use { it.connect(InetSocketAddress(server, port), 2500) }
            (System.currentTimeMillis() - start).toString()
        } catch (_: Exception) { "" }
        @JavascriptInterface fun coreLog(): String = GozarVpnService.lastLog(this@MainActivity)
        @JavascriptInterface fun getApps(): String = JSONArray().toString()
    }
}
