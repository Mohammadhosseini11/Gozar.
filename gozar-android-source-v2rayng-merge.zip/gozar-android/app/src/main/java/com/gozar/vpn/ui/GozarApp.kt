package com.gozar.vpn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF100E19)
private val Panel = Color(0xFF1B1828)
private val Purple = Color(0xFFB89AFF)
private val Muted = Color(0xFFA9A4B9)
private val White = Color(0xFFF8F6FF)

@Composable
fun GozarApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var showImport by remember { mutableStateOf(false) }
    var config by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("آماده برای پیکربندی") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple,
        onBackground = White, onSurface = White, secondary = Purple
    )) {
        Box(Modifier.fillMaxSize().background(Ink)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(
                        Brush.linearGradient(listOf(Color(0xFF9C77F5), Color(0xFF5842A0)))
                    ), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Shield, null, tint = White, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GOZAR", fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, color = White)
                        Text("مرزها را ساده‌تر ببین", fontSize = 12.sp, color = Muted)
                    }
                    IconButton(onClick = { selectedTab = 2 }) { Icon(Icons.Rounded.Settings, "تنظیمات", tint = Muted) }
                }
                Spacer(Modifier.height(28.dp))
                when (selectedTab) {
                    0 -> HomeScreen(message = message, onConnect = { message = "برای اتصال واقعی، ابتدا باید هستهٔ VPN ادغام و آزمایش شود." }, onImport = { showImport = true })
                    1 -> ServersScreen(onImport = { showImport = true }, hasConfig = config.isNotBlank())
                    else -> SettingsScreen()
                }
                Spacer(Modifier.weight(1f))
                NavigationBar(containerColor = Panel, contentColor = White, tonalElevation = 0.dp) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Rounded.Bolt, null) }, label = { Text("خانه") }, colors = navColors())
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Rounded.Dns, null) }, label = { Text("سرورها") }, colors = navColors())
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Rounded.Settings, null) }, label = { Text("تنظیمات") }, colors = navColors())
                }
                Spacer(Modifier.height(8.dp))
            }
            if (showImport) {
                AlertDialog(
                    onDismissRequest = { showImport = false },
                    containerColor = Panel,
                    title = { Text("افزودن کانفیگ", color = White) },
                    text = {
                        Column {
                            Text("لینک یا متن کانفیگ را وارد کن. در این نسخه، اتصال و اعتبارسنجی هسته هنوز فعال نیست.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(value = config, onValueChange = { config = it }, label = { Text("لینک یا کانفیگ") }, minLines = 3)
                        }
                    },
                    confirmButton = { TextButton(onClick = { showImport = false; message = if (config.isBlank()) "کانفیگی وارد نشده" else "کانفیگ ذخیرهٔ موقت شد؛ هنوز اعتبارسنجی نشده است." }) { Text("ذخیرهٔ موقت") } },
                    dismissButton = { TextButton(onClick = { showImport = false }) { Text("انصراف") } }
                )
            }
        }
    }
}

@Composable private fun HomeScreen(message: String, onConnect: () -> Unit, onImport: () -> Unit) {
    Text("اتصال امن،\nبا یک لمس.", fontSize = 31.sp, lineHeight = 39.sp, fontWeight = FontWeight.Bold, color = White)
    Spacer(Modifier.height(7.dp))
    Text("مسیر خودت را انتخاب کن؛ باقی مسیر با گذر.", color = Muted, fontSize = 14.sp)
    Spacer(Modifier.height(26.dp))
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(
        Brush.linearGradient(listOf(Color(0xFF29213F), Color(0xFF171421)))
    ).padding(vertical = 25.dp, horizontal = 18.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(158.dp).border(1.dp, Color(0xFF5C4B83), CircleShape).padding(11.dp).border(1.dp, Color(0xFF3D3158), CircleShape).padding(10.dp).clip(CircleShape).background(
                Brush.linearGradient(listOf(Color(0xFF8C6BE2), Color(0xFF44316F)))
            ), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Shield, null, tint = White, modifier = Modifier.size(62.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("قطع شده", color = White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("هستهٔ اتصال هنوز راه‌اندازی نشده", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onConnect, shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Ink), modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("شروع اتصال", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text(message, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
    Spacer(Modifier.height(18.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        MetricCard("زمان اتصال", "—", Modifier.weight(1f))
        MetricCard("ترافیک", "—", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Surface(onClick = onImport, color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Add, null, tint = Purple)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("افزودن کانفیگ", color = White, fontWeight = FontWeight.SemiBold); Text("لینک، متن یا اشتراک", color = Muted, fontSize = 12.sp) }
            Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(17.dp), modifier = modifier) {
        Column(Modifier.padding(15.dp)) { Text(title, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(8.dp)); Text(value, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun ServersScreen(onImport: () -> Unit, hasConfig: Boolean) {
    Text("سرورهای من", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
    Spacer(Modifier.height(8.dp))
    Text("کانفیگ‌ها را اینجا مدیریت کن.", color = Muted)
    Spacer(Modifier.height(22.dp))
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Dns, null, tint = Purple, modifier = Modifier.size(38.dp))
            Spacer(Modifier.height(10.dp))
            Text(if (hasConfig) "کانفیگ در حافظهٔ موقت موجود است" else "هنوز سروری اضافه نشده", color = White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("افزودن کانفیگ و اتصال واقعی در مراحل بعد تکمیل می‌شود.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onImport) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("افزودن کانفیگ") }
        }
    }
}

@Composable private fun SettingsScreen() {
    Text("تنظیمات", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
    Spacer(Modifier.height(8.dp)); Text("شخصی‌سازی تجربهٔ گذر", color = Muted)
    Spacer(Modifier.height(22.dp))
    listOf("هستهٔ اتصال" to "در حال بررسی: Xray و sing-box", "ظاهر" to "تم تیرهٔ اختصاصی", "نسخهٔ برنامه" to "0.1.0 · پیش‌نمونه").forEach { (title, subtitle) ->
        Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(4.dp)); Text(subtitle, color = Muted, fontSize = 12.sp) }
                Icon(Icons.Rounded.ArrowForward, null, tint = Muted)
            }
        }
    }
}

@Composable private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Purple, selectedTextColor = Purple,
    indicatorColor = Color(0xFF34284D), unselectedIconColor = Muted, unselectedTextColor = Muted
)
