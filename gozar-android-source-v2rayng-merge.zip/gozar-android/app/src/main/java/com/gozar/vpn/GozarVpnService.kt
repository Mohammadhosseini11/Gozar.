package com.gozar.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.util.Base64
import android.util.Log
import go.Seq
import libv2ray.CoreCallbackHandler
import libv2ray.Libv2ray
import org.json.JSONObject

/** Xray runtime bridge based on the public libv2ray API used by v2rayNG. */
class GozarVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.gozar.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.gozar.vpn.DISCONNECT"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_PARAMS = "vpn_params"
        private const val CHANNEL_ID = "gozar_vpn"
        private const val NOTIFICATION_ID = 7001
        private const val PREFS = "gozar_vpn_state"
        private const val KEY_STATE = "state"
        private const val KEY_LOG = "log"

        fun start(context: Context, config: String, params: String) {
            val intent = Intent(context, GozarVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_CONFIG, config)
                putExtra(EXTRA_PARAMS, params)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
        fun stop(context: Context) {
            context.startService(Intent(context, GozarVpnService::class.java).apply { action = ACTION_DISCONNECT })
        }
        fun state(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_STATE, "off") ?: "off"
        fun lastLog(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LOG, "هسته آماده است.") ?: "هسته آماده است."
    }

    private var tunInterface: ParcelFileDescriptor? = null
    private val core = Libv2ray.newCoreController(object : CoreCallbackHandler {
        override fun startup(): Long {
            markState("on", "هسته Xray فعال است.")
            return 0L
        }
        override fun shutdown(): Long {
            return 0L
        }
        override fun onEmitStatus(code: Long, message: String?): Long {
            val msg = message ?: "وضعیت هسته تغییر کرد."
            Log.i("GozarXray", msg)
            if (msg.contains("running", true) || msg.contains("started", true)) markState("on", msg)
            else saveLog(msg)
            return 0L
        }
    })
    private var configText = ""
    private var vpnParams = JSONObject()


    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        try {
            // Follow upstream v2rayNG initialization: the first argument is a writable
            // asset directory (geoip/geosite data), and the second is a stable XUDP device key.
            Seq.setContext(applicationContext)
            val assetPath = getDir("assets", Context.MODE_PRIVATE).absolutePath
            val androidId = (Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                ?: packageName).toByteArray(Charsets.UTF_8)
            val deviceId = Base64.encodeToString(
                androidId.copyOf(32), Base64.NO_PADDING or Base64.URL_SAFE
            )
            Libv2ray.initCoreEnv(assetPath, deviceId)
        } catch (e: Exception) {
            Log.e("GozarXray", "Xray environment initialization failed", e)
            markState("error", "آماده‌سازی محیط Xray ناموفق بود: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> { stopCore(); return START_NOT_STICKY }
            ACTION_CONNECT -> {
                configText = intent.getStringExtra(EXTRA_CONFIG).orEmpty()
                vpnParams = try { JSONObject(intent.getStringExtra(EXTRA_PARAMS) ?: "{}") } catch (_: Exception) { JSONObject() }
                if (configText.isBlank()) {
                    markState("error", "پیکربندی اتصال خالی است."); stopSelf(); return START_NOT_STICKY
                }
                startForeground(NOTIFICATION_ID, makeNotification("در حال اتصال…"))
                markState("connecting", "در حال راه‌اندازی هسته Xray…")
                Thread({ startCore() }, "Gozar-Xray-start").start()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCore() {
        try {
            establishTun()
            val tunFd = tunInterface?.fd ?: 0
            core.startLoop(configText, tunFd)
            if (core.isRunning) {
                markState("on", "هسته Xray فعال است.")
            } else {
                error("هستهٔ Xray پس از شروع، در وضعیت اجرا قرار نگرفت.")
            }
        } catch (e: Throwable) {
            Log.e("GozarXray", "Core start failed", e)
            markState("error", "راه‌اندازی هسته ناموفق بود: ${e.message ?: e.javaClass.simpleName}")
            stopCore(preserveError = true)
        }
    }

    /** Creates the Android TUN interface before handing its file descriptor to the current Xray API. */
    private fun establishTun() {
        val builder = Builder().setSession("Gozar VPN")
        // Match v2rayNG's default per-app rule: keep the VPN app itself outside its own TUN,
        // otherwise core outbound sockets can be routed back into the VPN and loop.
        builder.addDisallowedApplication(packageName)
        builder.setMtu(vpnParams.optInt("mtu", 1500).coerceIn(576, 9000))
        builder.addAddress("10.111.111.1", 30)
        builder.addRoute("0.0.0.0", 0)
        if (vpnParams.optBoolean("ipv6", false)) {
            builder.addAddress("fdfe:dcba:9876::1", 126)
            builder.addRoute("::", 0)
        }
        vpnParams.optString("dns", "1.1.1.1").split(",")
            .map { it.trim() }.filter { it.isNotEmpty() }
            .forEach { builder.addDnsServer(it) }
        tunInterface?.close()
        tunInterface = builder.establish() ?: error("Android did not establish the VPN interface")
        saveLog("رابط TUN ساخته شد.")
    }

    private fun stopCore(preserveError: Boolean = false) {
        try { if (core.isRunning) core.stopLoop() } catch (e: Exception) { Log.w("GozarXray", "Stop failed", e) }
        try { tunInterface?.close() } catch (_: Exception) { }
        tunInterface = null
        if (!preserveError) markState("off", "اتصال قطع شد.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun makeNotification(text: String): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = Notification.Builder(this, CHANNEL_ID)
        return builder.setContentTitle("Gozar").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(pending).setOngoing(true).build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Gozar VPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun markState(state: String, message: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATE, state).putString(KEY_LOG, message).apply()
        if (state == "on") getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, makeNotification("اتصال برقرار است"))
    }
    private fun saveLog(message: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LOG, message).apply()
    }
    override fun onRevoke() { stopCore(); super.onRevoke() }
    override fun onDestroy() {
        try { if (core.isRunning) core.stopLoop() } catch (_: Exception) { }
        try { tunInterface?.close() } catch (_: Exception) { }
        tunInterface = null
        super.onDestroy()
    }
}
