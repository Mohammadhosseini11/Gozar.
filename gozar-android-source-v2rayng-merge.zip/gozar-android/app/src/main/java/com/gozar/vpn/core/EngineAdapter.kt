package com.gozar.vpn.core

import org.json.JSONObject

/** Validation boundary for configs produced by the Gozar UI. Runtime lifecycle is owned by GozarVpnService. */
interface EngineAdapter {
    val id: String
    fun validateConfig(rawConfig: String): ConfigValidation
}

data class ConfigValidation(val valid: Boolean, val message: String)

/** Xray JSON config validation; actual runtime uses the upstream libv2ray AAR in GozarVpnService. */
class XrayEngineAdapter : EngineAdapter {
    override val id: String = "xray"
    override fun validateConfig(rawConfig: String): ConfigValidation = try {
        val json = JSONObject(rawConfig)
        val inbounds = json.optJSONArray("inbounds")
        val outbounds = json.optJSONArray("outbounds")
        if (inbounds != null && inbounds.length() > 0 && outbounds != null && outbounds.length() > 0) {
            ConfigValidation(true, "ساختار پیکربندی Xray معتبر است.")
        } else {
            ConfigValidation(false, "پیکربندی باید حداقل یک inbound و یک outbound داشته باشد.")
        }
    } catch (e: Exception) {
        ConfigValidation(false, "JSON پیکربندی معتبر نیست: ${e.message ?: "خطای نامشخص"}")
    }
}

/** sing-box/libbox is a separate engine and is not bundled by the v2rayNG Xray core integration. */
class SingBoxEngineAdapter : EngineAdapter {
    override val id: String = "sing-box"
    override fun validateConfig(rawConfig: String) = ConfigValidation(
        valid = false,
        message = "هستهٔ sing-box هنوز جداگانه به پروژه اضافه نشده است."
    )
}
