plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.gozar.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gozar.vpn"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
    sourceSets.getByName("main").jniLibs.srcDirs("libs")
    buildFeatures { compose = true }

    // Keep Java and Kotlin bytecode targets aligned to prevent JVM-target mismatch.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")
    // Prepared by scripts/setup-xray-core.sh from the official 2dust/AndroidLibXrayLite release.
    implementation(files("libs/libv2ray.aar"))
    debugImplementation("androidx.compose.ui:ui-tooling")
}
