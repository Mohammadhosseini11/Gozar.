# Upstream notices

Gozar fetches the Android binding from `2dust/AndroidLibXrayLite`, whose repository identifies its license as LGPL-3.0: https://github.com/2dust/AndroidLibXrayLite

The native `hev-socks5-tunnel` helper is built from the submodule pinned by `2dust/v2rayNG`, whose app repository identifies its license as GPL-3.0: https://github.com/2dust/v2rayNG

This notice is not a substitute for full upstream license texts or legal review. Include applicable license texts and source/offer notices in redistributed builds as required.
